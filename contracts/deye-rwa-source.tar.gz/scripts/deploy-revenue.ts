import hre from "hardhat";
import {assertPublicConfiguration, publicTestnet, ERC20_ABI} from "./revenue-network";
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { AbiCoder, getAddress, HDNodeWallet, getCreateAddress, keccak256 } from "ethers";
export type RevenueManifest = {
  version: "revenue-rights.v2";
  chainId: number;
  network: string;
  deployedBlock: number;
  deployedBlockHash: string;
  addresses: { usdc: string; station: string; vault: string; billing?: string };
  accounts: Record<string, string>;
  paymentToken?: {kind:"circle-test-usdc";symbol:"USDC";decimals:6};
  deploymentTransactions?: Record<string,string>;
  billingDeployment?: {transaction: string; block: number};
  scenarioId: string;
  localMaintenance?: {kind:"anvil-local-code-maintenance";previousCodeHash:string;codeHash:string;at:string;record:string};
  contractName?: "RevenueShareVaultV3" | "RevenueShareVaultV4" | "RevenueShareVaultV5";
};
function configured(name: string, fallback: string) {
  const value = process.env[`REVENUE_${name.toUpperCase()}_ADDRESS`];
  return getAddress(value || fallback);
}
export async function deployRevenue(): Promise<RevenueManifest> {
  const chainId=Number((await hre.ethers.provider.getNetwork()).chainId);
  assertPublicConfiguration(chainId);
  const signers = await hre.ethers.getSigners();
  if (signers.length < 8) throw new Error("Revenue deployment requires eight funded accounts");
  const [deployer, managerSigner, trusteeSigner, trustee2Signer, treasurySigner] =
    signers;
  const accounts = {
    admin: configured("admin", deployer.address),
    agent: configured("agent", managerSigner.address),
    trustee: configured("trustee", trusteeSigner.address),
    trustee2: configured("trustee2", trustee2Signer.address),
    treasury: configured("treasury", treasurySigner.address),
    owner: configured("owner", signers[5].address),
    investor: configured("investor", signers[6].address),
    investor2: configured("investor2", signers[7].address),
  };
  if (accounts.admin !== getAddress(deployer.address))
    throw new Error("Configured revenue admin must be the deployment signer");
  if (
    new Set([accounts.agent, accounts.trustee, accounts.trustee2]).size !== 3
  )
    throw new Error("Intermediary and both trustees require distinct addresses");
  const deploymentTransactions:Record<string,string>={};
  async function deployOne(key:string,name:string,args:unknown[]){
    const factory=await hre.ethers.getContractFactory(name);
    if(!publicTestnet(chainId)){
      const contract=await factory.deploy(...args);await contract.waitForDeployment();
      deploymentTransactions[key]=contract.deploymentTransaction()!.hash;return contract;
    }
    const journal=process.env.REVENUE_DEPLOYMENT_JOURNAL;
    if(!journal)throw new Error("Explicit Base Sepolia deployment journal required");
    mkdirSync(dirname(journal),{recursive:true});
    const records=existsSync(journal)?JSON.parse(readFileSync(journal,"utf8")):{};
    const request=await factory.getDeployTransaction(...args);
    const inputHash=keccak256(request.data!);
    let record=records[key];
    if(record&&(record.inputHash!==inputHash||record.chainId!==chainId||record.sender!==accounts.admin))throw new Error("Deployment journal does not match requested contracts");
    if(!record){
      const wallet=HDNodeWallet.fromPhrase(process.env.REVENUE_SYSTEM_MNEMONIC!).connect(hre.ethers.provider);
      const nonce=Number(BigInt(await hre.ethers.provider.send("eth_getTransactionCount",[wallet.address,"pending"])));
      const raw=await wallet.signTransaction(await wallet.populateTransaction({...request,nonce}));
      record={chainId,sender:accounts.admin,inputHash,raw,hash:keccak256(raw),address:getCreateAddress({from:wallet.address,nonce})};
      records[key]=record;writeFileSync(journal,JSON.stringify(records,null,2),{mode:0o600});
    }
    let receipt=await hre.ethers.provider.getTransactionReceipt(record.hash);
    if(!receipt){
      if(!await hre.ethers.provider.getTransaction(record.hash))await hre.ethers.provider.broadcastTransaction(record.raw);
      for(let i=0;i<180&&!receipt;i++){await new Promise(r=>setTimeout(r,1000));receipt=await hre.ethers.provider.getTransactionReceipt(record.hash);}
    }
    if(receipt?.status!==1)throw new Error(`Deployment ${key} did not succeed; inspect its journaled transaction`);
    deploymentTransactions[key]=record.hash;
    return factory.attach(record.address) as any;
  }
  const external = process.env.REVENUE_EXTERNAL_USDC;
  const usdc = external ? await hre.ethers.getContractAt(ERC20_ABI, getAddress(external)) : await deployOne("usdc","MockUSDC",[accounts.admin]);
  if(external){
    if(await hre.ethers.provider.getCode(external)==="0x" || Number(await usdc.decimals())!==6)throw new Error("External USDC must be a deployed six-decimal token");
  } else await usdc.waitForDeployment();

  const station = await deployOne("station","DeyeRWA",[accounts.admin]);
  const contractName=process.env.REVENUE_DISTRIBUTION_INTERVAL_MONTHS==="1"?"RevenueShareVaultV5":"RevenueShareVaultV4";
  const vault=await deployOne("vault",contractName,[accounts.admin,accounts.agent,accounts.trustee,accounts.trustee2,accounts.treasury,await usdc.getAddress(),await station.getAddress()]);
  if(!await station.hasRole(await station.ISSUER_ROLE(),accounts.agent))
    await (await station.grantRole(await station.ISSUER_ROLE(), accounts.agent)).wait();
  let billingAddress: string | undefined;
  let billingDeployment: RevenueManifest["billingDeployment"];
  if (process.env.REVENUE_HOUSEHOLD_PAYMENTS_ENABLED !== "false") {
    const billing=await deployOne("billing","HouseholdBilling",[await usdc.getAddress(),await vault.getAddress(),accounts.agent,accounts.treasury]);
    await billing.waitForDeployment();billingAddress=await billing.getAddress();
    const receipt=await hre.ethers.provider.getTransactionReceipt(deploymentTransactions.billing);billingDeployment={transaction:receipt!.hash,block:receipt!.blockNumber};
    if(!await vault.hasRole(await vault.TREASURY(),billingAddress))await (await vault.grantRole(await vault.TREASURY(), billingAddress)).wait();
  }
  const block = (await hre.ethers.provider.getBlock("latest"))!;
  return {
    version: "revenue-rights.v2",
    contractName,
    chainId: Number((await hre.ethers.provider.getNetwork()).chainId),
    network: hre.network.name,
    deployedBlock: block.number,
    deployedBlockHash: block.hash!,
    scenarioId: hre.ethers.id(
      `${Number((await hre.ethers.provider.getNetwork()).chainId)}:${await vault.getAddress()}`
    ),
    addresses: {
      usdc: await usdc.getAddress(),
      station: await station.getAddress(),
      vault: await vault.getAddress(),
      ...(billingAddress ? {billing:billingAddress}:{}),
    },
    accounts,
    deploymentTransactions: {...deploymentTransactions,...(billingDeployment?{billing:billingDeployment.transaction}:{})},
    ...(external?{paymentToken:{kind:"circle-test-usdc" as const,symbol:"USDC" as const,decimals:6 as const}}:{}),
    ...(billingDeployment?{billingDeployment}:{}),
  };
}
export async function verifyRevenue(manifest: RevenueManifest) {
  const items = [
    {
      address: manifest.addresses.usdc,
      source: "contracts/mocks/MockUSDC.sol",
      name: "MockUSDC",
      types: ["address"],
      args: [manifest.accounts.admin],
    },
    {
      address: manifest.addresses.station,
      source: "contracts/core/DeyeRWA.sol",
      name: "DeyeRWA",
      types: ["address"],
      args: [manifest.accounts.admin],
    },
    {
      address: manifest.addresses.vault,
      source: `contracts/revenue/${manifest.contractName || "RevenueShareVault"}.sol`,
      name: manifest.contractName || "RevenueShareVault",
      types: Array(7).fill("address"),
      args: [
        manifest.accounts.admin,
        manifest.accounts.agent,
        manifest.accounts.trustee,
        manifest.accounts.trustee2,
        manifest.accounts.treasury,
        manifest.addresses.usdc,
        manifest.addresses.station,
      ],
    },
  ];
  if (manifest.addresses.billing) items.push({address:manifest.addresses.billing,source:"contracts/revenue/HouseholdBilling.sol",name:"HouseholdBilling",types:Array(4).fill("address"),args:[manifest.addresses.usdc,manifest.addresses.vault,manifest.accounts.agent,manifest.accounts.treasury]});
  const results: Array<{ address: string; verified: boolean; message: string }> = [];
  const api = process.env.REVENUE_EXPLORER_API_URL?.replace(/\/$/u, "");
  for (const item of items) {
    if(manifest.chainId===84532)await new Promise(r=>setTimeout(r,2500));
    if(manifest.paymentToken && item.address===manifest.addresses.usdc) continue;
    if(manifest.localMaintenance&&item.address===manifest.addresses.vault){results.push({address:item.address,verified:false,message:"Local Anvil runtime maintenance; historical deployment verification is not verification of the new runtime. Check the current runtime against its source package."});continue;}
    try {
      if (!api) {
        await hre.run("verify:verify", {
          address: item.address,
          constructorArguments: item.args,
        });
      } else {
        const existing = await fetch(
          `${api}/api/v2/smart-contracts/${item.address}`,
          { signal: AbortSignal.timeout(5_000) }
        );
        if (existing.ok) {
          const contract = await existing.json();
          if (contract.is_verified === true) {
            results.push({
              address: item.address,
              verified: true,
              message: "already verified",
            });
            continue;
          }
        }
        const artifact = resolve(
          __dirname,
          `../artifacts/${item.source}/${item.name}.dbg.json`
        );
        const debug = JSON.parse(readFileSync(artifact, "utf8"));
        const buildInfo = JSON.parse(
          readFileSync(resolve(dirname(artifact), debug.buildInfo), "utf8")
        );
        const form = new FormData();
        form.append(
          "compiler_version",
          `v${String(buildInfo.solcLongVersion).split(".Emscripten")[0]}`
        );
        form.append("contract_name", `${item.source}:${item.name}`);
        form.append("autodetect_constructor_args", "false");
        form.append(
          "constructor_args",
          AbiCoder.defaultAbiCoder().encode(item.types, item.args).slice(2)
        );
        form.append(
          "files[0]",
          new Blob([JSON.stringify(buildInfo.input)], {
            type: "application/json",
          }),
          "standard-input.json"
        );
        const response = await fetch(
          `${api}/api/v2/smart-contracts/${item.address}/verification/via/standard-input`,
          { method: "POST", body: form, signal: AbortSignal.timeout(30_000) }
        );
        const text = await response.text();
        if (!response.ok)
          throw new Error(`Blockscout verification ${response.status}: ${text}`);
        let verified = false;
        for (let attempt = 0; attempt < 20 && !verified; attempt++) {
          const check = await fetch(
            `${api}/api/v2/smart-contracts/${item.address}`,
            { signal: AbortSignal.timeout(5_000) }
          );
          if (check.ok) {
            const contract = await check.json();
            verified = contract.is_verified === true;
          }
          if (!verified)
            await new Promise((done) => setTimeout(done, manifest.chainId===84532?2000:500));
        }
        if (!verified) throw new Error(`Blockscout did not verify: ${text}`);
      }
      results.push({ address: item.address, verified: true, message: "verified" });
    } catch (error) {
      const message = String((error as Error).message || error);
      if (/already verified|already been verified/iu.test(message))
        results.push({
          address: item.address,
          verified: true,
          message: "already verified",
        });
      else
        results.push({
          address: item.address,
          verified: false,
          message: message.slice(0, 240),
        });
    }
  }
  return results;
}
if (require.main === module)
  deployRevenue()
    .then((m) => {
      const output = JSON.stringify(m, null, 2);
      const out = process.argv[process.argv.indexOf("--out") + 1];
      if (process.argv.includes("--out")) writeFileSync(out, output);
      process.stdout.write(output + "\n");
    })
    .catch((e) => {
      console.error(e.message);
      process.exitCode = 1;
    });
